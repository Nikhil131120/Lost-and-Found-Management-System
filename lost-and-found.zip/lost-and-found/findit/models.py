from django.db import models

from accounts.models import Account

# Create your models here.
class Request(models.Model):
    title = models.CharField(max_length=255, verbose_name="Request Title")
    item_name = models.CharField(max_length=255, verbose_name="Lost Item")
    description = models.TextField(max_length=2047, verbose_name="Item Description")
    location = models.CharField(max_length=255)
    date = models.DateField(auto_now_add=True, verbose_name="Date Lost")
    owner = models.ForeignKey(Account, on_delete=models.CASCADE)
    reward = models.IntegerField(blank=True, null= True, default=0)
    is_found = models.BooleanField(default=False)
    def __str__(self) -> str:
        return self.title

class Item(models.Model):
    title = models.CharField(max_length=255)
    item_name = models.CharField(max_length=255, verbose_name="Lost Item")
    description = models.TextField(max_length=2047, verbose_name="Item Description")
    location = models.CharField(max_length=255)
    date = models.DateField(auto_now_add=True, verbose_name="Date Found")
    custody_of = models.ForeignKey(Account, on_delete=models.CASCADE)
    is_delivered = models.BooleanField(default=False)
    def __str__(self) -> str:
        return self.title