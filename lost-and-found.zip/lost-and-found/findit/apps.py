from django.apps import AppConfig


class FinditConfig(AppConfig):
    name = 'findit'
