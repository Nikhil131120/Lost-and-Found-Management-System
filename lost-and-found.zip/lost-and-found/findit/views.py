from django.shortcuts import redirect, render
from .models import *
from django.db.models import Q
from django.contrib.auth.decorators import login_required
# result_list = list(chain(page_list, article_list, post_list))
    # products = Product.objects.all().filter(is_available=True)
# Create your views here.
def findItem(req):
    desc = str(req.description).split()
    matches = Item.objects.filter(
            Q(title__icontains=req.title)|
            Q(description__icontains=req.title)|
            Q(item_name__icontains=req.title),
            Q(location__iexact=req.location),
            Q(date__iexact = req.date)
            )
    for i in desc:
        matches|=Item.objects.filter(
            Q(description__icontains=i)|
            Q(item_name__icontains=i),
            Q(location__iexact=req.location),
            Q(date__iexact = req.date)
        )
    if matches.exists():
        return matches
    else:
        return False

        
def findRequest(req):
    desc = str(req.description).split()
    matches = Request.objects.filter(
            Q(title__icontains=req.title)|
            Q(description__icontains=req.title)|
            Q(item_name__icontains=req.title),
            Q(location__iexact=req.location),
            Q(date__iexact = req.date)
            )
    for i in desc:
        matches|=Request.objects.filter(
            Q(description__icontains=i)|
            Q(item_name__icontains=i),
            Q(location__iexact=req.location),
            Q(date__iexact = req.date)
        )
    if matches.exists():
        return matches
    else:
        return False
@login_required
def submitrequest(request):
    if request.method=='POST':
        obj = Request(
            title = request.POST['title'],
            item_name = request.POST['item_name'],
            description = request.POST['description'],
            location = request.POST['location'],
            owner = request.user,
            reward = int(request.POST.get('reward',0))
        )
        obj.save()
        qs = findItem(obj)
        if qs:
            context = {
                'products': qs,
                'product_count': qs.count(),
            }
        else:
            context = {}
        return render(request, 'store/store.html', context)
    else:
        return render(request, 'store/submit_request.html')

@login_required
def reportitem(request):
    if request.method=='POST':
        obj = Item(
            title = request.POST['title'],
            item_name = request.POST['item_name'],
            description = request.POST['description'],
            location = request.POST['location'],
            custody_of = request.user,
        )
        obj.save()
        qs = findRequest(obj)
        if qs:
            context = {
                'products': qs,
                'product_count': qs.count(),
            }
        else:
            context = {}
        return render(request, 'store/store.html', context)
    else:
        return render(request, 'store/report_item.html')

@login_required
def checkagain(request):
    if request.method=="POST":
        obj = Request.objects.get(id=int(request.POST["id"]))
        qs = findItem(obj)
        if qs:
            context = {
                'products': qs,
                'product_count': qs.count(),
            }
        else:
            context = {}
        return render(request, 'store/store.html', context)
    else:
        return redirect('/accounts/myrequests/')

@login_required
def getitemdetails(request, id):
    obj = Item.objects.get(id=id)
    context={
        'single_product':obj
    }
    return render(request, 'store/product_detail.html', context)

@login_required
def getrequestdetails(request, id):
    obj = Request.objects.get(id=id)
    context={
        'single_product':obj
    }
    return render(request, 'store/product_detail.html', context)