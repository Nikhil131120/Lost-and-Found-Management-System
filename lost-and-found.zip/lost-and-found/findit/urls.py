from django.urls import path
from . import views


urlpatterns = [
    path('submitrequest/', views.submitrequest, name='submitrequest'),
    path('', views.submitrequest, name='submitrequest'),
    path('reportitem/', views.reportitem, name='reportitem'),
    path('submitrequest/', views.submitrequest, name='submitrequest'),
    path('checkagain/', views.checkagain, name='checkagain'),
    path('getitemdetails/<slug:id>', views.getitemdetails, name='getitemdetails'),
    path('getrequestdetails/<slug:id>', views.getrequestdetails, name='getrequestdetails'),


]
